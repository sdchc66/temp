gcloud builds submit . --machine-type n1-highcpu-32 --async


## Test
// curl http://tfserving-test:8080/api/dicom -X POST --data-binary @data.dcm
// hey -c 50 -z 10s -m POST -D ./data.dcm http://tfserving-test:8080/api/dicom
// curl -H "x-apicache-bypass: true" http://tfserving-test:8080/api/gcs/model/mr/b/uwisc032019/o/01297-Calf-1%2F1.2.826.0.1.3680043.2.629.20190228.31744600004918891286042385955.dcm
// hey -c 50 -z 10s -H "x-apicache-bypass: true" http://tfserving-test:8080/api/gcs/model/mr/b/uwisc032019/o/01297-Calf-1%2F1.2.826.0.1.3680043.2.629.20190228.31744600004918891286042385955.dcm

