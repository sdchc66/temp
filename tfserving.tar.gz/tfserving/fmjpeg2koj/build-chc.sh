#!/bin/bash
set -xe

TYPE=Release

BUILD_DIR=`pwd`
DEVSPACE=`pwd`

unamestr=`uname`

cd $DEVSPACE
[[ -d openjpeg ]] || git clone --branch=v2.4.0 --single-branch --depth 1 https://github.com/uclouvain/openjpeg.git
cd openjpeg
git pull
mkdir -p build-$TYPE
cd build-$TYPE
cmake .. -DCMAKE_BUILD_TYPE=$TYPE -DCMAKE_INSTALL_PREFIX:PATH=/usr
make -j8 install

cd $BUILD_DIR
mkdir -p build-$TYPE
cd build-$TYPE
cmake .. -DCMAKE_BUILD_TYPE=$TYPE -Dfmjpeg2k_ROOT=$DEVSPACE/fmjpeg2koj/$TYPE -DCMAKE_INSTALL_PREFIX:PATH=/usr
make -j8 install
